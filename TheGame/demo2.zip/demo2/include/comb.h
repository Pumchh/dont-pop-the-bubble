#ifndef COMB_H
#define COMB_H

#include "bn_keypad.h"
#include "bn_fixed_rect.h"
#include "bn_log.h"

#include "bn_display.h"

#include "bn_sprite_ptr.h"
#include "bn_sprite_animate_actions.h"
#include "bn_sprite_items_peigne.h"


class Comb {
private:
    bn::sprite_ptr spriteT;
    bn::sprite_ptr spriteB;
    bn::fixed_point positionT;
    bn::fixed_point positionB;



public:
    Comb(int x,int y, int space);
    void update();
    void gameover();
    bn::fixed_point getTopPosition();
    bn::fixed_point getBottomPosition();
    void hide();

};


#endif