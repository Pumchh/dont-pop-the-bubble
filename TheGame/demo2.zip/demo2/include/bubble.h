#ifndef BUBBLE_H
#define BUBBLE_H

#include "bn_keypad.h"
#include "bn_fixed_rect.h"
#include "bn_log.h"


#include "bn_display.h"

#include "bn_sprite_ptr.h"
#include "bn_sprite_animate_actions.h"
#include "bn_sprite_items_bulle16.h"
#include "bn_sprite_items_bulle.h"


class Bubble {
private:
    bn::sprite_ptr sprite;
    bn::fixed_point position;
    bn::fixed size;
    bn::fixed increment;

public:
    Bubble();
    void update();
    bool is_dead() const;
    void explode();
    bn::fixed_point getBubblePosition();
    bn::fixed getBubbleScale();
    bool is_alive;
    void hide();



    bn::fixed hitbox();


};

#endif