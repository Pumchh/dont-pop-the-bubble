//
// Created by Marti on 24/01/2025.
//

#ifndef DONT_POP_THE_BUBBLE_STEP1_H
#define DONT_POP_THE_BUBBLE_STEP1_H

#include "bn_regular_bg_ptr.h"

class Background_game1 {

public:
    Background_game1();

private:
    bn::regular_bg_ptr _background;

public:




};

#endif //DONT_POP_THE_BUBBLE_STEP1_H
