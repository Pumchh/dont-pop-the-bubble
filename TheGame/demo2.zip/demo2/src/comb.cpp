#include "comb.h"

Comb::Comb(int x,int y,int space):
        spriteT(bn::sprite_items::peigne.create_sprite(x, y)),
        spriteB(bn::sprite_items::peigne.create_sprite(x, y)),
        positionT(x, y),
        positionB(x, y+64+space)
        {
            spriteT.set_visible(false);
            spriteB.set_visible(false);
            spriteT.set_position(positionT);
            spriteB.set_position(positionB);
        }

/*void Comb::gameover() {

}*/

bn::fixed_point Comb::getTopPosition() {
    return spriteT.position();
}

bn::fixed_point Comb::getBottomPosition() {
    return spriteB.position();
}

void Comb::hide() {
    spriteT.set_visible(false);
    spriteB.set_visible(false);
}

void Comb::update() {
    spriteT.set_visible(true);
    spriteB.set_visible(true);
    spriteT.set_x(spriteT.x()-0.5);
    spriteB.set_x(spriteB.x()-0.5);   
}