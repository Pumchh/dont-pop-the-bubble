#include "bubble.h"

Bubble::Bubble() :
        sprite(bn::sprite_items::bulle.create_sprite(0, 0)),
        position(-40, 0),
        size(0.5),
        increment(0),
        is_alive(true)
        {
            sprite.set_visible(false);
            sprite.set_position(position);
            sprite.set_scale(size,size);
        }

void Bubble::update() {
    sprite.set_visible(true);

    if (!is_alive) return;

        if(bn::keypad::left_held())
        {
            sprite.set_x(sprite.x()-2);
            size = size - 0.005;
            if (size<=0) {
            size = 0.1;
        }
            sprite.set_scale(size,size);
            sprite.set_rotation_angle_safe(8); 
        }
        else if(bn::keypad::right_held())
        {
            sprite.set_x(sprite.x()+2);
            size = size - 0.005;
            if (size<=0) {
            size = 0.1;
        }
            sprite.set_scale(size,size);
            sprite.set_rotation_angle_safe(-8); 

        }
        if(bn::keypad::up_held())
        {
            sprite.set_y(sprite.y()-2);
            size = size - 0.005;
            if (size<=0) {
            size = 0.1;
        }
            sprite.set_scale(size,size);
            sprite.set_rotation_angle_safe(8); 

        }
        else if(bn::keypad::down_held())
        {
            sprite.set_y(sprite.y()+2);
            size = size - 0.005;
            if (size<=0) {
            size = 0.1;
        }
            sprite.set_scale(size,size);
            sprite.set_rotation_angle_safe(-8); 

        }

        if (bn::keypad::a_pressed()) {
            size = size + 0.1;
            sprite.set_scale(size,size);
        }

        if (bn::keypad::b_pressed()) {
            size = size - 0.01;
            if (size<=0) {
            size = 0.1;
        }
            sprite.set_scale(size,size);
        }

        if ( size < 0.005 || size > 2) {
            explode();
        }

        sprite.set_y(sprite.y()-0.5);

        /*increment = increment+1;
        if (increment == 60) {
        size = size - 0.1;
        increment = 0;
        }*/
}

bn::fixed_point Bubble::getBubblePosition() {
    return sprite.position();
}

bn::fixed Bubble::getBubbleScale() {
    return size;
}


bool Bubble::is_dead() const {
    return  !is_alive;
}

void Bubble::explode() {
    sprite.set_visible(false);
    is_alive=false;
}