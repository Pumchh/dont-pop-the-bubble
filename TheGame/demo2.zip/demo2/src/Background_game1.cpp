//
// Created by Marti on 24/01/2025.
//

#include "../include/Background_game1.h"
#include "bn_regular_bg_items_background_bathroom_256.h"


Background_game1::Background_game1():
    _background(bn::regular_bg_items::background_bathroom_256.create_bg(0, 0)) {
}

