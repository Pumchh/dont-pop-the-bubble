#include "bn_core.h"
#include <bn_regular_bg_ptr.h>
#include <bn_affine_bg_ptr.h>
#include "bn_affine_bg_builder.h"
#include "bn_affine_bg_actions.h"
#include "bn_affine_bg_attributes.h"
#include "bn_display.h"
#include "bubble.h"
#include "comb.h"
#include <bn_random.h>
#include <bn_vector.h>
#include "bn_log.h"


#include <bn_sprite_ptr.h>
#include "bn_keypad.h"

#include "bn_camera_actions.h"

#include "bn_bg_palettes.h"

#include "bn_music_items.h"
#include "bn_sound_items.h"
#include "bn_sprite_items_bulle.h"
#include "bn_regular_bg_items_water.h"
#include "bn_regular_bg_items_clouds.h"
#include "bn_regular_bg_items_gameover.h"
#include "bn_regular_bg_items_ecranlancement.h"
#include "bn_regular_bg_items_background_bathroom_256.h"


//#include "Background_game1.h"
#include "Player.h"
#include "Item_bathroom.h"
#include "bn_timer.h"

int main()
{
    bn::core::init();

    bn::timer timer;
    bool timerIsStarted = false;

    Player player;

    bn::regular_bg_ptr ecranlancement = bn::regular_bg_items::ecranlancement.create_bg();
    bn::regular_bg_ptr clouds = bn::regular_bg_items::clouds.create_bg();
    //bn::regular_bg_ptr water = bn::regular_bg_items::water.create_bg();
    bn::regular_bg_ptr bathroom = bn::regular_bg_items::background_bathroom_256.create_bg(0, 0);
    bn::regular_bg_ptr gameover = bn::regular_bg_items::gameover.create_bg();

    ecranlancement.set_visible(false);

    clouds.set_visible(false);
    bathroom.set_visible(false);
    //water.set_visible(false);
    gameover.set_visible(false);

    int gameStage = 1;

    Bubble bulle;
    bn::random r;

    //bn::music_items::canonind.play(0.5);


    bn::vector<Comb,10> peignes;

    int xPos = 0;
    for (int i=0;i<10;i++) {
    xPos +=64;
    int randomY = -32-r.get()%32;
    Comb peigne(xPos,randomY,32+r.get()%40);
    peignes.push_back(peigne);
    }



    Item_bathroom items[10];
    int max_bubble_apparition= 10;
    int nb_bubbles = 0;
    int time = 1000;

    while(true)
    {
        if (gameStage==1) {
        ecranlancement.set_visible(true);
 

            if (bn::keypad::a_pressed()) {
            bn::sound_items::intro.play(0.75);
            bn::sound_items::riff.play(0.75);
            bn::sound_items::outro.play(0.75);
            gameStage = 2;
        }

        }

        else if (gameStage == 2) {

            if (!timerIsStarted) {
                timer.restart();
                timerIsStarted = true;
            }

            ecranlancement.set_visible(false);
            bathroom.set_visible(true);

            //get the stuff in the bathroom
            for(int i=0; i<11; i++){
            if ((time-10) < (timer.elapsed_ticks() / 500) && (timer.elapsed_ticks() / 500) < time) {
                items[i].generate_item(timer.elapsed_ticks());
                time += 1000;
                nb_bubbles++;
            }
            if(items[i].check_collision(player.get_x(), player.get_y())){
                items[i].delete_item();
                player.level_up();
                BN_LOG("Level: ", player.get_level());
            }
        }

        player.update();

        if(nb_bubbles == max_bubble_apparition){
            BN_LOG("Fin du jeu, passage au jeu suivant");
            player.hide();
            gameStage = 3;
            //bathroom.set_visible(false);
            //bathroom->~bn::regular_bg_ptr();
            //items[10].delete_item();
            bn::sound_items::intro.play(0.75);
            bn::sound_items::riff.play(0.75);
            bn::sound_items::outro.play(0.75);
            bn::music_items::canonind.play(0.5);
        }
        }

        else if (gameStage == 3) {
            //flappy bubble
        ecranlancement.set_visible(false);
        bathroom.set_visible(false);

        clouds.set_visible(true);
        //water.set_visible(true);

        if (!bulle.is_dead()) {
            bulle.update();
        }

        bn::vector<Comb,6>::iterator it = peignes.begin();

        while(it<peignes.end()) {
            it->update();
            if (bulle.getBubblePosition().x() == it->getBottomPosition().x()-16) {
                /*BN_LOG("Bubble x : ",bulle.getBubblePosition().x());
                BN_LOG("Bubble y : ",bulle.getBubblePosition().y());
                BN_LOG("Bottom Comb x : ",it->getBottomPosition().x());
                BN_LOG("Bottom Comb y : ",it->getBottomPosition().y()-32);
                BN_LOG("Top Comb x : ",it->getTopPosition().x());
                BN_LOG("Top Comb y : ",it->getTopPosition().y()+32);
                
                BN_LOG("-----------------------------",it);*/
                if (bulle.getBubblePosition().y()+16 >= it->getBottomPosition().y()-32 ||  bulle.getBubblePosition().y()-16 <= it->getTopPosition().y()+32) {
                /*BN_LOG("Bubble x : ",bulle.getBubblePosition().x());
                BN_LOG("Bubble y : ",bulle.getBubblePosition().y());
                BN_LOG("Bottom Comb x : ",it->getBottomPosition().x());
                BN_LOG("Bottom Comb y : ",it->getBottomPosition().y());
                BN_LOG("Top Comb x : ",it->getTopPosition().x());
                BN_LOG("Top Comb y : ",it->getTopPosition().y());
                BN_LOG("-----------------------------",it);*/
                
                bulle.explode();
                if (!bulle.is_alive) {
                                   BN_LOG("Game Over !");
                //water.set_visible(false);
                clouds.set_visible(false);
                gameover.set_visible(true);

                    //it->hide();
                    gameStage =5 ;
                }
                }
            }

            
            it++;
        }

        clouds.set_x(clouds.x()-bn::fixed(.2));
        //water.set_x(water.x()-bn::fixed(1));

        }

        else if ( gameStage == 4 )
        {
            //Victory

        }

        else if (gameStage == 5) {
            //Game Over
                bn::vector<Comb,6>::iterator it = peignes.begin();
                while(it<peignes.end()) {
                    it->update();
                    it->hide();
                }
        }

        bn::core::update();
    }
}   
